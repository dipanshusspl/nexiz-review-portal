import { redirect } from 'next/navigation';
import { login } from '@/app/actions/auth';
import Flash from '@/components/Flash';
import Link from 'next/link';
import { getCurrentUser, homePath } from '@/lib/auth/current-user';
import Footer from '@/components/Footer';
import TrustBar from '@/components/TrustBar';
import LangSwitch from '@/components/LangSwitch';
import { getLang } from '@/lib/i18n';
import { authText, errorsAr } from '@/lib/auth-text';
import { providerConfigured, safeNext } from '@/lib/auth/oauth';
import PasswordField from '@/components/PasswordField';

export default async function LoginPage({ searchParams }: { searchParams: Promise<{ error?: string; ok?: string; next?: string }> }) {
  const me = await getCurrentUser();
  if (me) redirect(homePath(me));
  const sp = await searchParams;
  const lang = await getLang();
  const t = authText(lang);
  const next = safeNext(sp.next);
  const nq = next ? `?next=${encodeURIComponent(next)}` : '';
  return (
    <>
    <TrustBar lang={lang} />
    <main className="login-wrap" style={{ minHeight: 'calc(100vh - 150px)' }}>
      <div style={{ width: '100%', maxWidth: 400, display: 'flex', flexDirection: 'column', gap: 12 }}>
      <LangSwitch lang={lang} to="/login" />
      <form action={login} className="login-card" style={{ maxWidth: 'none' }}>
        <div className="brand big"><span className="logo">N</span>Nexiz AI</div>
        <h1>{t.signIn}</h1>
        {next && <input type="hidden" name="next" value={next} />}
        <Flash ok={sp.ok} error={sp.error} map={lang === 'ar' ? errorsAr : undefined} />
        <label>{t.email}<input name="email" type="email" required autoComplete="username" autoFocus dir="ltr" /></label>
        <PasswordField label={t.password} name="password" autoComplete="current-password" lang={lang} />
        <Link href="/forgot-password" className="small" style={{ alignSelf: 'flex-end', marginTop: -4 }}>{t.forgot}</Link>
        <button className="btn-primary wide">{t.signIn}</button>
        {(providerConfigured('google') || providerConfigured('linkedin')) && (
          <>
            {providerConfigured('google') && <a href={`/auth/google${nq}`} className="btn-ghost wide" style={{ textAlign: 'center' }}>{lang === 'ar' ? <>المتابعة باستخدام <bdi style={{ unicodeBidi: 'isolate' }} dir="ltr">Google</bdi></> : 'Continue with Google'}</a>}
            {providerConfigured('linkedin') && <a href={`/auth/linkedin${nq}`} className="btn-ghost wide" style={{ textAlign: 'center' }}>{lang === 'ar' ? <>المتابعة باستخدام <bdi style={{ unicodeBidi: 'isolate' }} dir="ltr">LinkedIn</bdi></> : 'Continue with LinkedIn'}</a>}
          </>
        )}
                <Link href="/expert" className="btn-ghost wide" style={{ textAlign: 'center' }}>
                  {lang === 'ar' ? 'ابدأ مراجعتك الآن (سجّل الدخول لاحقًا)' : 'Start your review now (sign in later)'}
                </Link>
        {/* <Link href="/products" className="btn-ghost wide" style={{ textAlign: 'center' }}>{t.browse}</Link> */}
      </form>
      </div>
    </main>
    <Footer lang={lang} />
    </>
  );
}